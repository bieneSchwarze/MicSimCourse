####################################################################################
####################################################################################
##  MICROSIMUALTION APPLICATION HYPOTHETICAL CHANGES OVER THE LIFE COURSE         ##
##                                                                                ##
##  Illustration 2: Lab Session MicSim                                            ##
##                                                                                ##
##  SZ, 30.08.2019                                                                ##
####################################################################################
####################################################################################

# Emptying workspace
rm(list=ls())
library(MicSim)

# Defining simulation horizon
simHorizon <- setSimHorizon(startDate="01/01/2014", endDate="31/12/2050")

# Defining maximum age
maxAge <- 110

# ---------------------------------------------------------------------------------
# Defining nonabsorbing and absorbing states
sex <- c("m","f")
fert <- c("0","1","2","3+")
marital <- c("NM","M","D","W")
edu <- c("no","low","med","high")
stateSpace <- expand.grid(sex=sex,fert=fert,marital=marital,edu=edu)
absStates <- c("dead","rest")

# ---------------------------------------------------------------------------------
# Specifying a base population; N=10000 individuals
# (In this example: Create base population randomly, though, following some commonsense
# rules based on based on limits imposed by the law and by human nature.)
N = 1000
initBirthDatesRange <- chron(dates=c("01/Jan/1964","01/Jan/2014"), format=c(dates="d/m/year"))
set.seed(124) # Set seed for random number generator (to make results repeatable)
birthDates <- dates(initBirthDatesRange[1] + runif(N, min=0, max=diff(initBirthDatesRange)))
getRandInitState <- function(birthDate){
  age <- trunc(as.numeric(simHorizon[1] - birthDate)/365.25)
  s1 <- sample(sex,1)
  s2 <- ifelse(age<=18, fert[1], ifelse(age<=22, sample(fert[1:3],1), sample(fert,1)))
  s3 <- ifelse(age<=18, marital[1], ifelse(age<=22, sample(marital[1:3],1), sample(marital,1)))
  s4 <- ifelse(age<=7, edu[1], ifelse(age<=18, edu[2], ifelse(age<=23, sample(edu[2:3],1),
    sample(edu[-1],1))))
  initState <- paste(c(s1,s2,s3,s4), collapse="/")
  return(initState)
}
initPop <- data.frame(ID=1:N, birthDate=birthDates, initState=sapply(birthDates,getRandInitState),
  stringsAsFactors=FALSE)

  # ---------------------------------------------------------------------------------
# Specifying the set of immigrants entering the population during simulation; M=2000 immigrants
# (In this example: Create immigrants randomly, though, following some commonsense
# rules based on based on limits imposed by the law and by human nature.)
M = 200
immigrDatesRange <- as.numeric(simHorizon)
immigrDates <- dates(chron(immigrDatesRange[1] + runif(M, min=0, max=diff(immigrDatesRange)),
  format=c(dates="d/m/year", times="h:m:s")))
immigrAges <- runif(M, min=15*365.25, max=50*365.25)
immigrBirthDates <- dates(chron(as.numeric(immigrDates) - immigrAges,
  format=c(dates="d/m/year",times="h:m:s")))
IDmig <- max(as.numeric(initPop[,"ID"]))+(1:M)
immigrPop <- data.frame(ID = IDmig, immigrDate = immigrDates, birthDate=immigrBirthDates,
  immigrInitState=sapply(immigrBirthDates,getRandInitState),stringsAsFactors=FALSE)

# ---------------------------------------------------------------------------------
# Defining set of transition rates used
# Fertility rates: first parity
fert1Rates <- function(age, calTime, duration){
  b <- ifelse(calTime<=2020, 5.5, 5.1)
  c <- ifelse(calTime<=2020, 28, 29)
  rate <-  (b/c)*(c/age)^(3/2)*exp(-b^2*(c/age+age/c-2))
  rate[age<=15 | age>=45] <- 0
  return(rate)
}
# Fertility rates: second and higher order parity
fert2Rates <- function(age, calTime, duration){
  b <- ifelse(calTime<=2020, 6.0, 5.7)
  c <- ifelse(calTime<=2020, 32, 33)
  rate <-  (b/c)*(c/age)^(3/2)*exp(-b^2*(c/age+age/c-2))
  rate[age<=15 | age>=45 | duration<0.75] <- 0
  return(rate)
}
# Transition rates to first marriage
marriage1Rates <- function(age, calTime, duration){
  b <- ifelse(calTime<=2020, 0.07, 0.10)
  p <- ifelse(calTime<=2020, 2.7,2.7)
  lambda <- ifelse(calTime<=2020, 0.04, 0.03)
  rate <- b*p*(lambda*age)^(p-1)/(1+(lambda*age)^p)
  rate[age<=16] <- 0
  return(rate)
}
# Transition rates to higher order marriage
marriage2Rates <- function(age, calTime, duration){
  b <- ifelse(calTime<=2020, 0.15, 0.17)
  p <- ifelse(calTime<=2020, 2.7, 3)
  lambda <- ifelse(calTime<=2020, 0.09, 0.1)
  rate <- b*p*(lambda*age)^(p-1)/(1+(lambda*age)^p)
  rate[age<=22] <- 0
  return(rate)
}
# Divorce rates
divorceRates <- function(age, calTime, duration){
  m <- 40
  s <- ifelse(calTime<=2020, 7, 6)
  rate <- 3*dnorm(age,mean=m,sd=s)
  rate[age<=18] <- 0
  return(rate)
}
# Transition rates to widowhood
widowhoodRates <- function(age, calTime, duration){
  rate <- ifelse(age<=30, 0, pgamma(age-20, shape=6, rate=0.02))
  return(rate)
}
# Transition rates to elementary school enrollment
noToLowEduRates <- function(age, calTime, duration){
  rate <- ifelse(age==7,Inf,0)
  return(rate)
}
# Transition rates to lower secondary education
lowToMedEduRates <- function(age, calTime, duration){
  rate <- dnorm(age,mean=16,sd=1)
  rate[age<=15 | age>=25] <- 0
  return(rate)
}
# Transition rates to upper secondary or tertiary education
medToHighEduRates <- function(age, calTime, duration){
  rate <- dnorm(age,mean=20,sd=3)
  rate[age<=18 | age>=35] <- 0
  return(rate)
}
# Mortality rates
mortRates <- function(age, calTime, duration){
  a <- 0.00003
  b <- ifelse(calTime<=2020, 0.1, 0.097)
  rate <- a*exp(b*age)
  return(rate)
}
# Emigration rates
emigrRates <- function(age, calTime, duration){
  rate <- ifelse(age<=18,0,0.0025)
  return(rate)
}

# ---------------------------------------------------------------------------------
# Defining transition matrix
fertTrMatrix <- cbind(c("0->1","1->2","2->3+","3+->3+"),
  c("fert1Rates", "fert2Rates", "fert2Rates","fert2Rates"))
maritalTrMatrix <- cbind(c("NM->M","M->D","M->W","D->M","W->M"),
  c("marriage1Rates","divorceRates","widowhoodRates", "marriage2Rates","marriage2Rates"))
eduTrMatrix <- cbind(c("no->low","low->med","med->high"),
  c("noToLowEduRates","lowToMedEduRates","medToHighEduRates"))
allTransitions <- rbind(fertTrMatrix, maritalTrMatrix, eduTrMatrix)
absTransitions <- rbind(c("dead","mortRates"),c("rest","emigrRates"))
transitionMatrix <- buildTransitionMatrix(allTransitions=allTransitions,
  absTransitions=absTransitions,stateSpace=stateSpace)

  # ---------------------------------------------------------------------------------
# Defining transitions triggering a birth event
fertTr <- fertTrMatrix[,1]

# Defining initial states for newborns and related occurrence probabilities
initStates <- rbind(c("m","0","NM","no"), c("f","0","NM","no"))
initStatesProb <- c(0.515,0.485)

# General date of enrollment to elementary school
dateSchoolEnrol <- "09/01"

# ---------------------------------------------------------------------------------
# Executing microsimulation (multicore run, five cores are accessed)
# If only one core is available, use the single core function `micSim' of the MicSim package,
# i.e., run the commented block given after this block.
# Beware that run time will increase substantially.
cores <- 4
seeds <- seeds <- c(1233, 1245, 1234, 5)
pop <- micSimParallel(initPop=initPop, immigrPop=immigrPop, transitionMatrix=transitionMatrix,
  absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
  maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr, dateSchoolEnrol=dateSchoolEnrol,
  cores=cores, seeds=seeds)

# # SINGLE CORE RUN
# set.seed(234)
# pop <- micSim(initPop=initPop, immigrPop=immigrPop, transitionMatrix=transitionMatrix,
#   absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
#   maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr, dateSchoolEnrol=dateSchoolEnrol)

# Transforming microsimulation output into long format
popLong <- convertToLongFormat(pop,migr=TRUE)

# Pick all newborns
ids <- c(initPop$ID, immigrPop$ID)
popLongNew <- popLong[!(popLong$ID %in% ids),]
popLongNew$SojTime <- (popLongNew$Tstop - popLongNew$Tstart)/ 365.25 # compute waiting times in states


